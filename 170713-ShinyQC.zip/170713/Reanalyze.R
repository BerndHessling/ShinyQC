# specify dataType folder
sampleTypeDir <- choose.dir(caption = "*** Select the sample type folder to be reanalyzed ***")

setwd(sampleTypeDir)

# load instruments and POI
Instruments <- read.delim("../Instruments.txt")

abbreviationLength <- unique(nchar(as.character(Instruments$Abbreviation)))

if(length(abbreviationLength) != 1){
  
  stop("Abbreviation length in the instrument.txt file are not consistent.
       Change to consistent length and start the script again")
  
}

PeptidesOfInterest <- read.delim("PeptidesOfInterest.txt")

# get file dates for all processed raw files
GEQC <- read.delim("globalEqc.txt")

fileDates <- GEQC[, c("Raw.file", "File.date")][!duplicated(GEQC[, c("Raw.file", "File.date")]), ]

# go to folder with MQ results
setwd("combined")

# get all MQ result folders
rawFileDirectories <- list.files(pattern = ".raw")

# initialize exist... variables
globalEqcExits <- FALSE

globalIdentqcExists <- FALSE

globalPOIExists <- FALSE

# loop through all MQ result folders
for(j in 1:length(rawFileDirectories)){
  
  # get fileDate
  fileDate <- as.character(fileDates[fileDates$Raw.file ==
                          substr(rawFileDirectories[j],
                                 start = 1,
                                 stop = nchar(rawFileDirectories[j]) - 4),2])
  
  # enter specific MQ result folder
  setwd(rawFileDirectories[j])
  
  # load and filter data
  
  summary <- read.delim("summary.txt")
  
  proteinGroups <- read.delim("proteinGroups.txt")
  
  proteinGroups$Reverse[is.na(proteinGroups$Reverse)] <- "-"
  
  proteinGroups$Potential.contaminant[is.na(
    proteinGroups$Potential.contaminant)] <- "-"
  
  proteinGroups$Only.identified.by.site[is.na(
    proteinGroups$Only.identified.by.site)] <- "-"
  
  filtered1 <- proteinGroups[proteinGroups$Reverse != "+", ]
  
  filtered2 <- filtered1[filtered1$Potential.contaminant != "+", ]
  
  filtered3 <- filtered2[filtered2$Only.identified.by.site != "+", ]
  
  evidenceQC <- read.delim("evidence.txt")
  
  evidenceQC$Reverse[is.na(evidenceQC$Reverse)] <- "-"
  
  evidenceQC$Potential.contaminant[is.na(
    evidenceQC$Potential.contaminant)] <- "-"
  
  evidenceQC <- evidenceQC[evidenceQC$Reverse != "+", ]
  
  evidenceQC <- evidenceQC[evidenceQC$Potential.contaminant != "+", ]
  
  # Transform data
  evidenceQC$Retention.length[evidenceQC$Retention.length == 1] <- NaN
  
  evidenceQC$Missed.cleavages <- as.factor(evidenceQC$Missed.cleavages)
  
  # get data frame with numbers only
  ints <- sapply(evidenceQC, is.integer)
  
  numbs <- sapply(evidenceQC, is.numeric)
  
  intsAndNums <- ints|numbs
  
  evidenceQCForBP <- evidenceQC[ ,intsAndNums]
  
  eqc <- data.frame(matrix(ncol = 6, nrow = dim(evidenceQCForBP)[2]))
  
  # define colnames
  colnames(eqc) <- c("Parameter",
                     "ymin",
                     "firstQuantile",
                     "median",
                     "thirdQuantile",
                     "ymax")
  
  # calculate boxplot parameters
  for (i in 1:dim(evidenceQCForBP)[2]) {
    
    eqc[i ,2:6] <- unname(quantile(evidenceQCForBP[ ,i], na.rm = TRUE))
    
    eqc[i ,1] <- colnames(evidenceQCForBP)[i]
    
    iqr <- eqc[i, 5] - eqc[i, 3]
    
    eqc[i, 2] <-  min(
      evidenceQCForBP[
        evidenceQCForBP[ ,i] >
          (eqc[i, 3] - (1.5 * iqr)),
        i], na.rm = TRUE)
    
    eqc[i, 6] <-  max(
      evidenceQCForBP[
        evidenceQCForBP[ ,i] <
          (eqc[i, 5] + (1.5 * iqr)),
        i], na.rm = TRUE)
    
  }
  
  # instrument, abbreviation, file date and raw file
  eqc$Abbreviation <- substr(as.character(evidenceQC$Raw.file[1]),
                             start = 1,
                             stop = abbreviationLength)
  
  eqc$Raw.file <- evidenceQC$Raw.file[1]
  
  eqc$File.date <- fileDate
  
  eqc <- merge(x = eqc,
               y = Instruments,
               by = "Abbreviation")
  
  if(globalEqcExits){
    
    globalEqc <- rbind(globalEqc, eqc)
    
  } else {
    
    globalEqc <- eqc
    
    globalEqcExits <- TRUE
    
  }
  
  # globalIdentQC
  
  identqc <- data.frame(matrix(ncol = 3, nrow = 2))
  
  colnames(identqc) <- c("Identified.peptides", "Identified.proteins", "identified.MSMS.in.percentage")
  
  identqc$Identified.peptides <- length(unique(evidenceQC$Sequence))
  
  identqc$Identified.proteins <- length(unique(filtered3$Majority.protein.IDs))
  
  identqc$identified.MSMS.in.percentage <- summary$MS.MS.Identified....[1]
  
  # instrument, abbreviation, file date and raw file
  identqc$Abbreviation <- substr(as.character(evidenceQC$Raw.file[1]),
                                 start = 1,
                                 stop = abbreviationLength)
  
  identqc$Raw.file <- evidenceQC$Raw.file[1]
  
  identqc$File.date <- fileDate
  
  identqc <- merge(x = identqc,
                   y = Instruments,
                   by = "Abbreviation")
  
  
  if(globalIdentqcExists){
    
    globalIdentqc <- rbind(globalIdentqc, identqc)
    
  } else {
    
    globalIdentqc <- identqc
    
    globalIdentqcExists <- TRUE
    
  }
  
  # globalPOIQC
  forPOIqc <- evidenceQC[order(evidenceQC$Raw.file,
                               evidenceQC$Modified.sequence,
                               evidenceQC$Charge,
                               -evidenceQC$Intensity), ]
  
  forPOIqc <- forPOIqc[!duplicated(
    forPOIqc[ ,c("Raw.file", "Modified.sequence", "Charge")]), ]
  
  POIqc <- merge(x = PeptidesOfInterest,
                 y = forPOIqc,
                 by = c("Modified.sequence", "Charge"))
  
  if(dim(POIqc)[1] > 0){
    
    POIqc$File.date <- fileDate
    
    POIqc$Abbreviation <- substr(as.character(evidenceQC$Raw.file[1]),
                                 start = 1,
                                 stop = abbreviationLength)
    
    POIqc <- merge(x = POIqc,
                   y = Instruments,
                   by = "Abbreviation")
    
  }
  
  if(globalPOIExists){
    
    globalPOIqc <- rbind(globalPOIqc, POIqc)
    
  } else {
    
    globalPOIqc <- POIqc
    
    globalPOIExists <- TRUE

  }
  
  setwd("..")
  
}

setwd("..")

globalEqc$File.date <- as.POSIXct(globalEqc$File.date)

globalIdentqc$File.date <- as.POSIXct(globalIdentqc$File.date)

globalPOIqc$File.date <- as.POSIXct(globalPOIqc$File.date)

file.copy(from = "globalIdentqc.txt",
          to = "globalIdentqc.txt.beforeReanalyze",
          overwrite = TRUE)

file.copy(from = "globalEqc.txt",
          to = "globalEqc.txt.beforeReanalyze",
          overwrite = TRUE)

file.copy(from = "globalPOIqc.txt",
          to = "globalPOIqc.txt.beforeReanalyze",
          overwrite = TRUE)

write.table(globalIdentqc,
            file = "globalIdentqc.txt",
            sep = "\t",
            row.names = FALSE)

write.table(globalEqc,
            file = "globalEqc.txt",
            sep = "\t",
            row.names = FALSE)

write.table(globalPOIqc,
            file = "globalPOIqc.txt",
            sep = "\t",
            row.names = FALSE)
