shinyServer(function(input, output) {
  
  #############################################################################
  #### Buttons ####
  #############################################################################
  
  #  update data button
  observeEvent(input$Update, {
    
    UpdateData()
    print(reactiveData$GIQC[][reactiveData$GIQC[ ,6] %in% input$instruments, ])

  })

  #  logbook button
  observeEvent(input$logBookEntry, {
    
    setwd(parentDir)
    
    reactiveData$logBook <- read.delim("logBook.txt")
    
    file.copy(from = paste0(parentDir, "/logBook.txt"),
              to = paste0(parentDir, "/logBook.txt.bak"), overwrite = TRUE)
    
    reactiveData$newLogBookEntry <- t(c(as.character(input$logBookType),
                                        paste(as.character(input$logBookDate),
                                              as.character(input$logBookTime)),
                                        as.character(input$logBookInstrument),
                                        as.character(input$logBookText),
                                        as.character(input$logBookUser)))
    
    colnames(reactiveData$newLogBookEntry) <- colnames(reactiveData$logBook)
    
    reactiveData$logBook <- rbind(reactiveData$logBook,
                                  reactiveData$newLogBookEntry)
    
    reactiveData$logBook[ ,2] <- as.POSIXct(reactiveData$logBook[ ,2])
    
    
    write.table(reactiveData$logBook,
                paste0(parentDir, "/logBook.txt"),
                row.names = FALSE,
                sep = "\t")
    
  })
  
  #  undo logbook entry
  observeEvent(input$logBookReset, {
    
    setwd(parentDir)
    
    file.copy(from = paste0(parentDir, "/logBook.txt.bak"),
              to = paste0(parentDir, "/logBook.txt"), overwrite = TRUE)
    
    logBook <- read.delim("logBook.txt")
    
    logBook[ ,2] <- as.POSIXct(logBook[ ,2])
    
    reactiveData$logBook <- logBook
    
  })
  
  ###################################################################################
  #### Get Global variables ####
  ###################################################################################
  
  #  Extract row numbers of RawFile that match current date selection  
  ForRawFileFactors <- reactive({
    
    which(reactiveData$GEQC[][ ,FileDateNum] >=
            as.POSIXct(input$dateRange)[1] &
            reactiveData$GEQC[][ ,FileDateNum] <=
            as.POSIXct(input$dateRange)[2])
  })
  
  #  Extract factor levels of RawFiles that match current date selection
  #  for GlobalPlot/scale_file_manual/breaks
  RawFileFactors <- reactive({
    
    unique(reactiveData$GEQC[ForRawFileFactors(),
                             RawFileNum])
  })
  
  ###################################################################################
  #### Get data to be plotted ####
  ###################################################################################

  
  #  Border values for current dataType selcetion
  hline <- reactive({
    
    borders[borders$ColumnName == input$dataType & borders$Instrument %in% input$instruments, ]
  })
  
  
  ###################################################################################
  #### Create plots ####
  ###################################################################################
  
  #  IDPlot
  # vline addition works only if date was was put in aes as numeric
  output$IDPlot <- renderPlot({
    
    ggplot(reactiveData$GIQC[][reactiveData$GIQC[ ,7] %in% input$instruments, ],
           aes_string(x = "File.date",
                      y = input$IDType,
                      colour = "Instrument")) +
      
      geom_point() +
      
      geom_line() +
      
      scale_colour_manual(values = rep(brewer.pal(8,"Dark2"),
                                       times = 100),
                          drop = TRUE,
                          breaks = as.character(RawFileFactors())) +
      
      scale_x_datetime(limits = as.POSIXct(input$dateRange)) +
      
      theme(axis.text.x = element_text(angle = 22.5,
                                       hjust = 1))  +
      
      geom_vline(data = reactiveData$logBook[][reactiveData$logBook[ ,3] %in% input$instruments, ],
                 aes(xintercept = as.numeric(Date),
                     linetype = Entry),
                 show.legend = FALSE,
                 colour = "darkgrey") +
      
      expand_limits(y=0) +
      
      facet_wrap(~Instrument)
        
  })
  
  #  GlobalPlot
  output$GlobalPlot <- renderPlot({
    
    
    ggplot(data = reactiveData$GEQC[][reactiveData$GEQC[ ,10] %in% input$instruments &
                                        reactiveData$GEQC[ ,2] == input$dataType &
                                        reactiveData$GEQC[ ,9] >= as.POSIXct(input$dateRange[1]) &
                                        reactiveData$GEQC[ ,9] <= as.POSIXct(input$dateRange[2]), ],
           
           aes(File.date, fill = Instrument)) +
    
    geom_boxplot(aes(ymin = ymin,
                     lower = firstQuantile,
                     middle = median,
                     upper = thirdQuantile,
                     ymax = ymax,
                     width = 20000),
                 outlier.size = 0,
                 position = "dodge",
                 na.rm = TRUE,
                 stat = "identity") +
      
      scale_fill_manual(values = rep(brewer.pal(8,"Dark2"),
                                     times = 100),
                        drop = FALSE,
                        breaks = as.character(RawFileFactors())) +
      
      scale_x_datetime(limits = as.POSIXct(input$dateRange)) +
      
      geom_hline(data = hline(),
                 aes_string(yintercept = "HighValue"),
                 colour = "red",
                 linetype = "dashed",
                 na.rm = TRUE) +
      
      geom_hline(data = hline(),
                 aes_string(yintercept = "LowValue"),
                 colour = "red",
                 linetype = "dashed",
                 na.rm = TRUE) +
      
      geom_hline(data = hline(),
                 aes_string(yintercept = "OptimalValue"),
                 colour = "darkgreen",
                 linetype = "dashed",
                 na.rm = TRUE) +
      
      geom_vline(data = reactiveData$logBook[][reactiveData$logBook[ ,3] %in% input$instruments, ],
                 aes(xintercept = as.numeric(Date),
                            linetype = Entry),
                 show.legend = FALSE,
                 colour = "darkgrey") +
      
      theme(axis.text.x = element_text(angle = 22.5,
                                       hjust = 1),
            legend.position = "bottom") +
      
      ylab(input$dataType) +
      
      facet_wrap(~Instrument) +
      
      if(input$logY){
        
        scale_y_log10()
        
      }

  })
  
  
  #  POIPlot
  output$POIPlot <- renderPlot({
    
    ggplot(reactiveData$GPOIQC[][reactiveData$GPOIQC[ ,dim(GPOIQC)[2]] %in% input$instruments &
                                   reactiveData$GPOIQC[ ,ncol(GPOIQC)-1] >= as.POSIXct(input$dateRange[1]) &
                                   reactiveData$GPOIQC[ ,ncol(GPOIQC)-1] <= as.POSIXct(input$dateRange[2]), ],
           aes_string(x = "File.date",
                      y = input$dataType,
                      colour = "Modified.sequence")) +
      
      scale_colour_manual(values = rep(brewer.pal(8,"Dark2"),
                                       times = 100)) +
      
      geom_point() +
      
      geom_line() +
      
      scale_x_datetime(limits = as.POSIXct(input$dateRange)) +
      
      
      geom_hline(data = hline(),
                 aes_string(yintercept = "HighValue"),
                 colour = "red",
                 linetype = "dashed",
                 na.rm = TRUE) +
      
      geom_hline(data = hline(),
                 aes_string(yintercept = "LowValue"),
                 colour = "red",
                 linetype = "dashed",
                 na.rm = TRUE) +
      
      geom_hline(data = hline(),
                 aes_string(yintercept = "OptimalValue"),
                 colour = "darkgreen",
                 linetype = "dashed",
                 na.rm = TRUE) +
      
      geom_vline(data = reactiveData$logBook[][reactiveData$logBook[ ,3] %in% input$instruments, ],
                 aes(xintercept = as.numeric(Date),
                     linetype = Entry),
                 colour = "darkgrey") +
      
      theme(axis.text.x = element_text(angle = 22.5,
                                       hjust = 1),
            legend.position = "bottom")  +
      
      facet_wrap(~Instrument) +
      
      if(input$logY){
        
        scale_y_log10()
        
      }
      

  })

  ###################################################################################
  #### Create Table ####
  ###################################################################################
  
  #  LogBookTable
  output$LogBookTable <- renderDataTable({
    reactiveData$logBook
  })

})
