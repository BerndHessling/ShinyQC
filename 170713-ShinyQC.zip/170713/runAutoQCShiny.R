if (!require("ggplot2")) {
  
  install.packages("ggplot2", dependencies = TRUE)
  
  library(ggplot2)
}

if (!require("RColorBrewer")) {
  
  install.packages("RColorBrewer", dependencies = TRUE)
  
  library(RColorBrewer)
}

if (!require("shiny")) {
  
  install.packages("shiny", dependencies = TRUE)
  
  library(shiny)
  
}

if (!require("scales")) {
  
  install.packages("scales", dependencies = TRUE)
  
  library(scales)
}

###############################################################################
### get directory paths ###
###############################################################################


sampleTypeDir <- choose.dir(caption = "*** Select the sample type folder ***")

setwd(sampleTypeDir)

setwd("..")

parentDir <- getwd()

###############################################################################
### load static variables ###
###############################################################################

#  data file used for extracting column selection numbers
#  (see server.r: FileDateNum, RawFileNum...)
setwd(sampleTypeDir)

data <- read.delim("globalEqc.txt") # could be deleted and replaced by GEQC

#  POI used for POI data extraction (see server.r/globalPOI) DELTE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
POI <- read.delim("PeptidesOfInterest.txt")

#  borders used for horizontal lines in both plots (see server.r/hline)

borders <-read.delim("borders.txt")

borders$ColumnName <- as.character(borders$ColumnName)

borders$Instrument <- as.factor(borders$Instrument)

setwd(parentDir)

logBookChoices <- read.delim("logBookChoices.txt")

#  create num vectors for certain columns from global variable "data"
#  to extract from "reactiveData$GEQC"
 FileDateNum <- which(colnames(data) == "File.date")
# 
 RawFileNum <- which(colnames(data) == "Raw.file")


###############################################################################
### load reactiveData ###
###############################################################################

#  create ReactiveData list
reactiveData <- reactiveValues()

#  load and setup logbook
logBook <- read.delim("logBook.txt")

logBook[ ,2] <- as.POSIXct(logBook[ ,2])

#  load and setup GEQC
setwd(sampleTypeDir)

GEQC <- read.delim("globalEqc.txt")

GEQC[ ,"File.date"] <- as.POSIXct(GEQC[ ,"File.date"])

#  load and setup GIQC

GIQC <- read.delim("globalIdentqc.txt")

GIQC[ ,"File.date"] <- as.POSIXct(GIQC[ ,"File.date"])

#  load and setup globalPOIqc

GPOIQC <- read.delim("globalPOIqc.txt")

GPOIQC[ ,"File.date"] <- as.POSIXct(GPOIQC[ ,"File.date"])

#  setup reactive objects
reactiveData$GEQC <- GEQC

reactiveData$GIQC <- GIQC

reactiveData$GPOIQC <- GPOIQC

reactiveData$logBook <- logBook

###############################################################################
### create functions ###
###############################################################################

#  function that updates data including factor level sorting for RawFile
UpdateData <- function(){
  
  #  load and reformate data
  setwd(sampleTypeDir)
  
  GEQC <- read.delim("globalEqc.txt")
  
  GEQC[ ,"File.date"] <- as.POSIXct(GEQC[ ,"File.date"])
  
  GIQC <- read.delim("globalIdentqc.txt")
  
  GIQC[ ,"File.date"] <- as.POSIXct(GIQC[ ,"File.date"])
  
  GPOIQC <- read.delim("globalPOIqc.txt")
  
  GPOIQC[ ,"File.date"] <- as.POSIXct(GPOIQC[ ,"File.date"])
  
  #  setup reactive objects
  reactiveData$GEQC <- GEQC
  
  reactiveData$GIQC <- GIQC
  
  reactiveData$GPOIQC <- GPOIQC
  
  reactiveData$logBook <- logBook
  
  setwd(parentDir)
  
  reactiveData$logBook <- read.delim("logBook.txt")
  
  reactiveData$logBook[ ,2] <- as.POSIXct(reactiveData$logBook[ ,2])
  
}

###############################################################################
### Run app ###
###############################################################################

runApp(parentDir, host="0.0.0.0",port=3168)