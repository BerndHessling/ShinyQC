###############################################################################
############################# QC-Setup ########################################
###############################################################################

#  get qc data folder
dataFolder <- choose.dir(caption = "Select the DataFolder")

#  set WD
setwd(dataFolder)

#  check for sample type folders
STFolders <- list.dirs(full.names = FALSE, recursive = FALSE)

#  copy files in sample type folders
for(i in 1:length(STFolders)){
  
  # copy PeptidesOfInterest.txt
  file.copy(from = paste0(getwd(), "/TemplateFiles/PeptidesOfInterest.txt"),
            to = paste0(getwd(), "/", STFolders[i]),
            overwrite = FALSE)
  
  # copy dummy.raw
  file.copy(from = paste0(getwd(), "/TemplateFiles/dummy.raw"),
            to = paste0(getwd(), "/", STFolders[i]),
            overwrite = FALSE)

}