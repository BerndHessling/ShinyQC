setwd(parentDir)
instruments <- read.delim("Instruments.txt")

instrumentchoices <- vector()

instrumentselected <- vector()

for(i in seq(from = 1, to = dim(instruments)[1])){
  
  instrumentchoices[i] <- as.character(instruments[i,2])
  
  names(instrumentchoices[i]) <- as.character(instruments[i,2])
  
}

for(i in seq(from = 1, to = dim(instruments)[1])){
  
  instrumentselected[i] <- as.character(instruments[i,2])
  
}
  
shinyUI(fluidPage(
  
  sidebarPanel(
    
    #  Upddate file Button
    h2("Start App"),
    
    actionButton(inputId = "Update",
                 label = "Start app/Update data"),
    
    h2("Choose data to be plotted"),
    
    h3("Global parameters"),
    
    dateRangeInput(inputId = "dateRange",
                   label = "Date range input: yyyy-mm-dd",
                   start = Sys.Date() - 14,
                   end = Sys.Date()),
    
    checkboxGroupInput(inputId = "instruments",
                       label = "Check instruments to be included",
                       choices = instrumentchoices, # needs to changed (calculate vector in before)
                       selected = instrumentselected), # same

    br(),
    
    h3("ID plot parameters"),
    
    selectInput(inputId = "IDType",
                label = "Choose ID level:",
                choices = c("Identified.peptides",
                            "Identified.proteins"),
                selected = "Identified.peptides"),
    
    br(),
    
    h3("QC plots parameters"),
    
    selectInput(inputId = "dataType",
                label = "Data to be plotted:",
                choices = as.character(GEQC$Parameter[!duplicated(GEQC$Parameter)]),
                
                #choices = na.omit(unique(as.character(data$Parameter))[unique(data$Parameter) ==
                #                                           borders$ColumnName[borders$Include]]),
                selected = "Uncalibrated.Mass.Error..ppm."),
    
    strong("log y-axis"),
    
    checkboxInput("logY", label = "y-axis log10", value = FALSE),
    
    br(),
    
    br(),
    
    h2("Create logbook entry"),
    
    selectInput(inputId = "logBookInstrument",
                label = "Instrument's logbook",
                choices = as.character(unique(data$Instrument)),
                selected = as.character(unique(data$Instrument)[1])),
    
    selectInput(inputId = "logBookType",
                label = "Type of entry",
                choices = as.character(
                  unique(logBookChoices$LogBookEntries)),
                selected = as.character(
                  unique(logBookChoices$LogBookEntries)[1])),
    
    dateInput("logBookDate",
              label = "Date of entry: yyyy-mm-dd",
              value = Sys.Date()),
    
    textInput("logBookTime",
              label ="Time of Entry: hh:mm",
              value = "10:00"),
    
    textInput("logBookText",
              label = strong("Comment:"),
              value = ""),
    
    selectInput(inputId = "logBookUser",
                label = "User",
                choices = as.character(
                  unique(logBookChoices$LogBookUsers)),
                selected = as.character(
                  unique(logBookChoices$LogBookUsers)[1])),
    actionButton(inputId = "logBookEntry",
                 label = strong("Create entry")),
    
    br(),
    
    h3("Undo last logbook entry"),
    
    actionButton(inputId = "logBookReset",
                 label = strong("Undo"))

  ),
  
  mainPanel(
    
    tabsetPanel(
      
      tabPanel("Plots",
               h4("Number of identified peptides"),
               plotOutput("IDPlot"),
               h4("Global data of all peptides"),
               plotOutput("GlobalPlot"),
               h4("Specific data for peptides of interest"),
               plotOutput("POIPlot")),
      
      tabPanel("LogBook",
               dataTableOutput("LogBookTable"))
  ))
))