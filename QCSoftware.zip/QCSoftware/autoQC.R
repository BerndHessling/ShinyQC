###############################################################################
##### load requirede packages #####
###############################################################################


if (!require("ggplot2")) {
  
  install.packages("ggplot2", dependencies = TRUE)
  
  library(ggplot2)
}

if (!require("RColorBrewer")) {
  
  install.packages("RColorBrewer", dependencies = TRUE)
  
  library(RColorBrewer)
}

###############################################################################
##### get directories #####
###############################################################################

dir <- paste0(choose.dir(caption = "***Please choose the DataFolder***"), "/")

MQDir <- choose.dir(caption = "***Please choose the MaxQuant/bin/ folder***")

checkForSpaces <- c(grepl(" ", dir), grepl(" ", MQDir))

if(any(checkForSpaces)){
  
  stop("   DataFolder or MaxQuant path contains spaces, program stops!")
  
}

###############################################################################
##### get sample types #####
###############################################################################

sampleTypes <- list.dirs(dir,full.names = FALSE, recursive = FALSE)

TemplateLoc <- grepl("TemplateFiles", x = sampleTypes)

sampleTypes <- sampleTypes[!TemplateLoc]

###############################################################################
##### Start infinite loop #####
###############################################################################


while(1>0){
  
  #  check for existing files
  rawFiles <- list.files(path = dir,
                         pattern = "^.*\\.raw$")
  
  if(length(rawFiles) != 0) {
    
    ###########################################################################
    ##### Run MaxQuant #####
    ###########################################################################
    
    #  Set working directory
    setwd(dir)
    
    #  File statement
    print(paste0(Sys.time(), "   Found file ", rawFiles[1]))
    
    #  Make sure file is copied completely
    Sys.sleep(60)
    
    #  Extract file creation time
    FileInfo <- file.info(paste0(dir, "/", rawFiles[1]))
    
    FileDate <- FileInfo$mtime
    
    FileSize <- FileInfo$size
    
    #  Get sample type of raw file
    sampleTypesID <- vector(length = length(sampleTypes))
    
    for(i in 1:length(sampleTypes)){
      sampleTypesID[i] <- grepl(sampleTypes[i], rawFiles[1])
      
    }
    
    #  check if raw file name matches a defined sample type
    if(any(sampleTypesID)){
      
      sampleType <- sampleTypes[sampleTypesID]
      
      sampleTypeDir <- paste0(dir, sampleType, "/")
      
      
      #  ensure file is not corrupt by file size and check if already processed
      if(FileSize > 10000000 & !
         (file.exists(paste0(sampleTypeDir, "combined/", rawFiles[1])))){
        
        #  Move files
        file.copy(from = paste0(dir, rawFiles[1]),
                  to = paste0(sampleTypeDir, rawFiles[1]))
        
        file.remove(paste0(dir, rawFiles[1]))
        
        #  Edit xml file
        setwd(sampleTypeDir)
        
        XML <- readLines("mqpar.xml")
        
        XML <- gsub(pattern = "dummy.raw",
                    replacement = rawFiles[1],
                    x = XML,
                    fixed = TRUE)
        
        writeLines(XML, "mqpar2.xml")
        
        #  Run MQ
        MQCommand <- paste0(MQDir,
                            "/MaxQuantCmd.exe ",
                            sampleTypeDir,
                            "mqpar2.xml")
        
        MQCommand <- gsub("\\\\", "/", MQCommand)
        
        print(paste0(Sys.time(),
                     "   Start maxquant analysis of file ",
                     rawFiles[1]))
        
        system(MQCommand)
        
        #  Delete files
        file.remove(paste0(sampleTypeDir, rawFiles[1]))
        
        file.remove(paste0(sampleTypeDir,"mqpar2.xml"))
        
        unlink(paste0(sampleTypeDir,
                      substr(rawFiles[1],
                             1,
                             nchar(rawFiles[1])-4)),
               recursive = TRUE)
        
        file.remove(paste0(sampleTypeDir,
                           substr(rawFiles[1],
                                  1,
                                  nchar(rawFiles[1])-4),
                           ".index"))
        
        #  Rename result folder
        file.rename(from = paste0(sampleTypeDir,
                                  "Combined/txt"),
                    to =paste0(sampleTypeDir,
                               "Combined/",
                               rawFiles[1]))
        
        ### Processed statement ###
        print(paste0(Sys.time(),
                     "   Finished MQ search file ",
                     rawFiles[1]))
        
        ##########################################
        ### Create QC Plots ###
        ##########################################
        
        #  Setup WD and project name
        setwd(paste0(sampleTypeDir,
                     "combined/",
                     rawFiles[1]))
        
        projectName <- substr(rawFiles[1],
                              1,
                              nchar(rawFiles[1])-4)
        
        ### Load data ###
        proteinGroups <- read.delim("proteinGroups.txt")
        
        evidenceQC <- read.delim("evidence.txt")
        
        msScans <- read.delim("msScans.txt")
        
        msmsScansQC <- read.delim("msmsScans.txt")
        
        ### Create colour palletes ###
        my2Palette <- c("#d95f02",
                        "#1b9e77") # first colours of Dark2 pallette
        
        ### Filter data ###
        proteinGroups$Reverse[is.na(proteinGroups$Reverse)] <- "-"
        
        proteinGroups$Potential.contaminant[is.na(
          proteinGroups$Potential.contaminant)] <- "-"
        
        proteinGroups$Only.identified.by.site[is.na(
          proteinGroups$Only.identified.by.site)] <- "-"
        
        evidenceQC$Reverse[is.na(evidenceQC$Reverse)] <- "-"
        
        evidenceQC$Potential.contaminant[is.na(
          evidenceQC$Potential.contaminant)] <- "-"
        
        filtered1 <- proteinGroups[proteinGroups$Reverse != "+", ]
        
        filtered2 <- filtered1[filtered1$Potential.contaminant != "+", ]
        
        filtered3 <- filtered2[filtered2$Only.identified.by.site != "+", ]
        
        evidenceQC <- evidenceQC[evidenceQC$Reverse != "+", ]
        
        evidenceQC <- evidenceQC[evidenceQC$Potential.contaminant != "+", ]
        
        ### Transform data ###
        evidenceQC$Retention.length[evidenceQC$Retention.length == 1] <- NaN
        
        evidenceQC$Missed.cleavages <- as.factor(evidenceQC$Missed.cleavages)
        
        ##################################
        ### Create Plots ###
        ##################################
        
        ### Mass error plot ###
        MassErrorPlot <- ggplot(evidenceQC,
                                aes(x= Raw.file,
                                    y = Uncalibrated.Mass.Error..ppm.)) +
          
          scale_colour_manual(values = rep(brewer.pal(8,"Dark2"),
                                           times = 4)) +
          
          geom_jitter(alpha = 0.2) +
          
          geom_boxplot(colour = "black",
                       fill = NA, outlier.size = 0,
                       lwd = 1) +
          
          ggtitle("uncalibrated mass error [ppm]") +
          
          coord_cartesian(ylim = c(-10,10))
        
        ### MSMS identified vs unidentified by RT ###
        msmsPlot <- ggplot(msmsScansQC,
                           aes(x = Retention.time,
                               fill = Identified)) +
          
          scale_fill_manual(values = my2Palette) +
          
          geom_bar(binwidth = max(msmsScansQC$Retention.time /
                                    (30 + 0.5 * max(
                                      msmsScansQC$Retention.time)))) +
          
          ggtitle("Identified vs unidentified MSMS over RT per Raw File")
        
        ### Elution length plot ###
        ElutionLengthPlot <- ggplot(evidenceQC,
                                    aes(x= Raw.file,
                                        y = Retention.length)) +
          
          scale_colour_manual(values = rep(brewer.pal(8,"Dark2"),
                                           times = 4)) +
          
          geom_jitter(alpha = 0.2) +
          
          geom_boxplot(colour = "black",
                       fill = NA,
                       outlier.size = 0,
                       lwd = 1) +
          
          ggtitle("Retention length of identified peptides [min]") +
          
          coord_cartesian(ylim = c(0,5))
        
        ### Data points per feature ###
        DataPointsPlot <- ggplot(evidenceQC,
                                 aes(x= Raw.file,
                                     y = Number.of.data.points)) +
          
          scale_colour_manual(values = rep(brewer.pal(8,"Dark2"),
                                           times = 4)) +
          
          geom_jitter(alpha = 0.2) +
          
          geom_boxplot(colour = "black",
                       fill = NA,
                       outlier.size = 0,
                       lwd = 1) +
          
          ggtitle("Number of data point per peptide") +
          
          coord_cartesian(ylim = c(0,250))
        
        ##################################
        ### Print Plots ###
        ##################################
        
        pdf(paste0(projectName, "_", "QCPlots.pdf"),
            width = 20.6,
            height = 11.6)
        
        print(MassErrorPlot)
        
        print(msmsPlot)
        
        print(ElutionLengthPlot)
        
        print(DataPointsPlot)
        
        dev.off()
        
        ### Processed statement ###
        print(paste0(Sys.time(),
                     "   Finished writing QC-pdf for ",
                     rawFiles[1]))
        
        
        ##########################################
        ### Create global QC Data ###
        ##########################################
        
        ### Create/Extend globalEqc ###
        setwd(dir)
        
        # load instrument file and get length of abbreviation
        Instruments <- read.delim("Instruments.txt")
        
        abbreviationLength <- unique(nchar(as.character(Instruments$Abbreviation)))
        
        if(length(abbreviationLength) != 1){
          
          stop("Abbreviation length in the instrument.txt file are not consistent.
               Change to consistent length and start the script again")
          
        }
        
        # check for existing files
        setwd(sampleTypeDir)
        
        globalEqcExits <- file.exists("globalEqc.txt")
        
        globalPOIExists <- file.exists("globalPOIqc.txt")
        
        globalIdentqcExists <- file.exists("globalIdentqc.txt")
        
        # load PeptidesOfInterest
        
        PeptidesOfInterest <- read.delim("PeptidesOfInterest.txt")
        
        #######################################################################
        ############# create eqc ##############################################
        #######################################################################
        
        # get data frame with numbers only
        ints <- sapply(evidenceQC, is.integer)
        
        numbs <- sapply(evidenceQC, is.numeric)
        
        intsAndNums <- ints|numbs
        
        evidenceQCForBP <- evidenceQC[ ,intsAndNums]
        
        eqc <- data.frame(matrix(ncol = 6, nrow = dim(evidenceQCForBP)[2]))
        
        # define colnames
        colnames(eqc) <- c("Parameter",
                            "ymin",
                            "firstQuantile",
                            "median",
                            "thirdQuantile",
                            "ymax")
        
        # calculate boxplot parameters
        for (i in 1:dim(evidenceQCForBP)[2]) {
          
          eqc[i ,2:6] <- unname(quantile(evidenceQCForBP[ ,i], na.rm = TRUE))
          
          eqc[i ,1] <- colnames(evidenceQCForBP)[i]
          
          iqr <- eqc[i, 5] - eqc[i, 3]
          
          eqc[i, 2] <-  min(
            evidenceQCForBP[
              evidenceQCForBP[ ,i] >
                (eqc[i, 3] - (1.5 * iqr)),
              i], na.rm = TRUE)
          
          eqc[i, 6] <-  max(
            evidenceQCForBP[
              evidenceQCForBP[ ,i] <
                (eqc[i, 5] + (1.5 * iqr)),
              i], na.rm = TRUE)
          
        }
        
        # instrument, abbreviation, file date and raw file
        eqc$Abbreviation <- substr(as.character(evidenceQC$Raw.file[1]),
                                          start = 1,
                                          stop = abbreviationLength)
        
        eqc$Raw.file <- evidenceQC$Raw.file[1]
        
        eqc$File.date <- FileDate
        
        eqc <- merge(x = eqc,
                     y = Instruments,
                     by = "Abbreviation")
        
        if(globalEqcExits){
          
          globalEqc <- read.delim("globalEqc.txt")
          
          write.table(globalEqc,
                      file = "globalEqc.txt.bak",
                      sep = "\t",
                      row.names = FALSE)
          
          globalEqc$File.date <- as.POSIXct(globalEqc$File.date)
          
          globalEqc <- rbind(globalEqc, eqc)
          
        } else {
          globalEqc <- eqc
          
          globalEqc$File.date <- as.POSIXct(globalEqc$File.date)
          
        }
        
        write.table(globalEqc,
                    file = "globalEqc.txt",
                    sep = "\t",
                    row.names = FALSE)
        
        bordersExists <- file.exists("borders.txt")
        
        #######################################################################
        ### create Identqc ####################################################
        #######################################################################
        
        identqc <- data.frame(matrix(ncol = 2, nrow = 2))
        
        colnames(identqc) <- c("Identified.peptides", "Identified.proteins")
        
        identqc$Identified.peptides <- length(unique(evidenceQC$Sequence))
        
        identqc$Identified.proteins <- length(unique(evidenceQC$Leading.Razor.Protein))
        
        
        # instrument, abbreviation, file date and raw file
        identqc$Abbreviation <- substr(as.character(evidenceQC$Raw.file[1]),
                                   start = 1,
                                   stop = abbreviationLength)
        
        identqc$Raw.file <- evidenceQC$Raw.file[1]
        
        identqc$File.date <- FileDate
        
        identqc <- merge(x = identqc,
                     y = Instruments,
                     by = "Abbreviation")
        
        
        if(globalIdentqcExists){
          
          globalIdentqc <- read.delim("globalIdentqc.txt")
          
          write.table(globalIdentqc,
                      file = "globalIdentqc.txt.bak",
                      sep = "\t",
                      row.names = FALSE)
          
          globalIdentqc$File.date <- as.POSIXct(globalIdentqc$File.date)
          
          globalIdentqc <- rbind(globalIdentqc, identqc)
          
        } else {
          
          globalIdentqc <- identqc
          
          globalIdentqc$File.date <- as.POSIXct(globalIdentqc$File.date)
          
        }
        
        write.table(globalIdentqc,
                    file = "globalIdentqc.txt",
                    sep = "\t",
                    row.names = FALSE)
        
        
        #######################################################################
        ### create POIqc ######################################################
        #######################################################################
        
        forPOIqc <- evidenceQC[order(evidenceQC$Raw.file,
                                     evidenceQC$Modified.sequence,
                                     evidenceQC$Charge,
                                     -evidenceQC$Intensity), ]
        
        forPOIqc <- forPOIqc[!duplicated(
          forPOIqc[ ,c("Raw.file", "Modified.sequence", "Charge")]), ]
        
        POIqc <- merge(x = PeptidesOfInterest,
              y = forPOIqc,
              by = c("Modified.sequence", "Charge"))
        
        POIqc$File.date <- FileDate
        
        POIqc$Abbreviation <- substr(as.character(evidenceQC$Raw.file[1]),
                                       start = 1,
                                       stop = abbreviationLength)
        
        POIqc <- merge(x = POIqc,
                         y = Instruments,
                         by = "Abbreviation")
        
        
        if(globalPOIExists){
          
          globalPOIqc <- read.delim("globalPOIqc.txt")
          
          
          
          write.table(globalPOIqc,
                      file = "globalPOIqc.txt.bak",
                      sep = "\t",
                      row.names = FALSE)
          
          globalPOIqc$File.date <- as.POSIXct(globalPOIqc$File.date)
          
          globalPOIqc <- rbind(globalPOIqc, POIqc)
          
        } else {
          
          globalPOIqc <- POIqc
          
          globalPOIqc$File.date <- as.POSIXct(globalPOIqc$File.date)
          
        }
        
        write.table(globalPOIqc,
                    file = "globalPOIqc.txt",
                    sep = "\t",
                    row.names = FALSE)
        
        # border file
        
        if(!bordersExists){
          
          borders <- as.data.frame(globalEqc$Parameter)
          
          borders$LowValue <- NA
          
          borders$HighValue <- NA
          
          borders$OptimalValue <- NA
          
          borders$Include <- NA
          
          borders$Instrument <- NA
          
          names(borders)[1] <- "ColumnName"
          
          borders$LowValue[borders$ColumnName == "Uncalibrated.Mass.Error..ppm."] <- -5
          
          borders$HighValue[borders$ColumnName == "Uncalibrated.Mass.Error..ppm."] <- 5
          
          borders$OptimalValue[borders$ColumnName == "Uncalibrated.Mass.Error..ppm."] <- 0
          
          borders <- as.data.frame(do.call("rbind",
                                           replicate(dim(Instruments)[1],
                                                     borders,
                                                     simplify = FALSE)))
          
          startVec <- seq(from = 1,
                          to = dim(borders)[1] - dim(borders)[1] / dim(Instruments)[1] + 1,
                          length.out = dim(Instruments)[1])
          
          stopVec <- seq(from = dim(borders)[1] / dim(Instruments)[1],
                         to = dim(borders)[1],
                         length.out = dim(Instruments)[1])
          
          for(i in 1:dim(Instruments)[1]){
            
            borders$Instrument[startVec[i]:stopVec[i]] <- as.character(Instruments$Instrument[i])
            
          }
          
          
          
          write.table(borders,
                      file = "borders.txt",
                      sep = "\t",
                      row.names = FALSE)
        }
        
      } else {
        
        file.remove(paste0(dir, rawFiles[1]))
        
        print(paste0(
          Sys.time(), 
          "   File already processed or too small and therefore deleted"))
        
      }
      
      
      
    } else {
      
      file.remove(paste0(dir, rawFiles[1]))
      
      print(paste0(
        Sys.time(), 
        "   File name does not match any defined sample type"))
      
    }
    
    ###########################################################################
    ##### Set in sleep mode #####
    ###########################################################################
    
  } else {
    
    print(paste0(Sys.time(),
                 "   No more raw files to process; check again in 2 min"))
    
    Sys.sleep(120)
    
  }
  
}